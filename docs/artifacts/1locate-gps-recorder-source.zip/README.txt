Full file snapshots for the current 1Locate route configuration and GPS recorder changes. Includes the preceding route-builder refinements, unchanged supplied school map asset, additive SQL migration and installation guide. Apply to the same 1Locate checkout; this is not a standalone replacement repository. No credentials, .env files, dependencies or build output are included.

Read docs/gps-outdoor-recorder.md first.
Checks: 177 admin tests, 222 mobile tests passed; both production builds passed. Admin Android Capacitor geolocation plugin synchronized.
Not performed: live SQL migration/RLS verification, APK installation, physical camera/GPS campus survey.
